﻿angular.module('ema.controllers')

.controller('CancelarTicketController', function ($scope) {


})