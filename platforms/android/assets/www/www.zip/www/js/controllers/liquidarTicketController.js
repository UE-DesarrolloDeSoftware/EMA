﻿angular.module('ema.controllers')

.controller('LiquidarTicketController', function ($scope) {


})