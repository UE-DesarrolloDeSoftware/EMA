angular.module('ema.controllers')

 .controller('MenuVendedorController', function ($scope, $state) {

 })